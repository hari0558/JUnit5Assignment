package com.yash.service;

import java.util.Arrays;

public class ArrayOperations {

	public int[] sortArray(int[] array) {
		Arrays.sort(array);
		return array;
	}

}
