package com.yash.service;

public class Calculation {

	public int computeMultiplication(int a,int b) {
		
		return a*b;
	}

}
