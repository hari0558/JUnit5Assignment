package com.yash.service;

import java.util.ArrayList;
import java.util.List;

public class GetList {
	public List<Integer>getIntegerList(){
		List<Integer>list=new ArrayList<Integer>();
		list.add(22);
		list.add(1);
		list.add(16);
		list.add(10);
		list.add(19);
		list.add(9);
		return list;
		
	}

}
