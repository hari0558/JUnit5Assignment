package com.yash.test;

import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.hamcrest.core.IsCollectionContaining;
import org.junit.Before;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.yash.service.Calculation;
import com.yash.service.GetList;

class FilterTesting {
	private List<Integer>list;
	@Before
	void setUp() {
		list=new GetList().getIntegerList();
	}

	@AfterEach
	void tearDown() throws Exception {
		list=null;
	}

	@DisplayName("Test1: To Check Elements R Present or not")
	@Tag("FAST")
	@Test
	void test1() {
		assertThat(list,IsCollectionContaining.hasItems(22,9,10));
	}

	@DisplayName("Test2: Test to Check No Is Greater than 20")
	@Tag("SLOW")
	@Test
	void test2() {
		Calculation cal=new Calculation();
		assertTrue(cal.computeMultiplication(11,2)>22);
	}
	

}
