package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.yash.meta.Feature1;
import com.yash.meta.Feature2;
import com.yash.service.ArrayOperations;
import com.yash.service.Calculation;

class MetaTesting {

	@Feature1
	void testCalculation() {
		Calculation cal=new Calculation();
		int a=11;
		int b=2;
		int expected=22;
		int actual=cal.computeMultiplication(a,b);
		assertEquals(expected,actual);
	}

	@Feature2
	void testArraySorting() {
		ArrayOperations operation=new ArrayOperations();
		int[] array   = {1,9,4,2};
		int[] expected= {1,2,4,9};
		int[] actual=operation.sortArray(array);
		assertEquals(expected,actual);
		
	}
}
